CREATE SEQUENCE seq_book;
CREATE SEQUENCE seq_author INCREMENT BY 7 MINVALUE 10000 NO CYCLE;
CREATE TYPE AgeType AS ENUM ('young', 'middle-aged', 'old');

CREATE TABLE Schriftstueck (
	   SID INTEGER DEFAULT nextval('seq_book'), 
       Titel VARCHAR(255),
	   Seiten INTEGER NOT NULL,
       PRIMARY KEY(SID)
);

CREATE TABLE Sachbuch (
	   SID INTEGER,
       FOREIGN KEY (SID) REFERENCES Schriftstueck(SID),
	   PRIMARY KEY(SID)
);

CREATE TABLE Lyrik (
	   SID INTEGER,
       FOREIGN KEY (SID) REFERENCES Schriftstueck(SID),
	   PRIMARY KEY(SID)
);

CREATE TABLE Roman (
	   SID INTEGER,
	   Genre VARCHAR(255) NOT NULL,
       FOREIGN KEY (SID) REFERENCES Schriftstueck(SID),
	   PRIMARY KEY(SID)
);

CREATE TABLE ueber (
       Sachbuch INTEGER,
       Roman INTEGER,
       FOREIGN KEY (Sachbuch) REFERENCES Sachbuch(SID),
       FOREIGN KEY (Roman) REFERENCES Roman(SID),
	   PRIMARY KEY(Sachbuch, Roman)
);

CREATE TABLE Autorin (
	   AID INTEGER DEFAULT nextval('seq_author'),
       Name VARCHAR(255),
       GebDat DATE,
	   PRIMARY KEY(AID)
);

CREATE TABLE schrieb (
       Autorin INTEGER,
       Schriftstueck INTEGER,
	   StartDatum DATE NOT NULL,
       FOREIGN KEY (Autorin) REFERENCES Autorin(AID),
       FOREIGN KEY (Schriftstueck) REFERENCES Schriftstueck(SID),
	   PRIMARY KEY(Autorin, Schriftstueck)
);

CREATE TABLE Verlag (
       Name VARCHAR(255),
	   Budget NUMERIC(10,2) NOT NULL CHECK(Budget >= 10 AND Budget <= 1000000),
	   HauptabteilungStadt VARCHAR(255), 
	   HauptabteilungBereich VARCHAR(255),
	   PRIMARY KEY(Name)
);

CREATE TABLE Edition (
       Schriftstueck INTEGER,
	   EDNR INTEGER, 
	   Jahr INTEGER NOT NULL CHECK(Jahr >= 1400),
	   Verlagsname VARCHAR(255) NOT NULL,
	   ErstauflageANR INTEGER,
       FOREIGN KEY (Schriftstueck) REFERENCES Schriftstueck(SID),
       FOREIGN KEY (Verlagsname) REFERENCES Verlag(Name),
	   PRIMARY KEY(Schriftstueck, EDNR)
);

CREATE TABLE Sonderedition (
       Schriftstueck INTEGER,
	   EDNR INTEGER, 
	   Anlass VARCHAR(255) NOT NULL,
       FOREIGN KEY (Schriftstueck, EDNR) REFERENCES Edition(Schriftstueck, EDNR),
	   PRIMARY KEY(Schriftstueck, EDNR)
);

CREATE TABLE Auflage (
       Schriftstueck INTEGER,
	   EDNR INTEGER, 
	   ANR INTEGER,
	   Druckerei VARCHAR(255) NOT NULL,
       FOREIGN KEY (Schriftstueck, EDNR) REFERENCES Edition(Schriftstueck, EDNR),
	   PRIMARY KEY(Schriftstueck, EDNR, ANR)
);

CREATE TABLE Abteilung (
       Verlagsname VARCHAR(255),
	   Bereich VARCHAR(255) CHECK(Bereich ~ $$^\w{2}\d{3}$$),
	   Stadt VARCHAR(255),
       FOREIGN KEY (Verlagsname) REFERENCES Verlag(Name),	   
	   PRIMARY KEY(Verlagsname, Bereich, Stadt)
);

ALTER TABLE Verlag ADD CONSTRAINT fk_Hauptabteilung
      FOREIGN KEY (Name, HauptabteilungStadt, HauptabteilungBereich) REFERENCES Abteilung(Verlagsname, Stadt, Bereich)
      DEFERRABLE INITIALLY DEFERRED;

ALTER TABLE Edition ADD CONSTRAINT fk_Erstauflage
      FOREIGN KEY (Schriftstueck, EDNR, ErstauflageANR) REFERENCES Auflage(Schriftstueck, EDNR, ANR)
      DEFERRABLE INITIALLY DEFERRED;

CREATE TABLE Marketingkanal (
       KName VARCHAR(255),
	   Kosten NUMERIC(10,2) NOT NULL,
	   PRIMARY KEY(KName)
);

CREATE TABLE Social (
       Kanal VARCHAR(255),
	   Platform VARCHAR(255) NOT NULL,
       FOREIGN KEY (Kanal) REFERENCES Marketingkanal(KName),	   
	   PRIMARY KEY(Kanal)
);

CREATE TABLE Zeitung (
       Kanal VARCHAR(255),
	   Schriftstueck INTEGER,
	   Auflage INTEGER NOT NULL,
       FOREIGN KEY (Kanal) REFERENCES Marketingkanal(KName),	   
       FOREIGN KEY (Schriftstueck) REFERENCES Schriftstueck(SID),	   
	   PRIMARY KEY(Kanal, Schriftstueck)
);

CREATE TABLE Zielgruppe (
       Bez VARCHAR(255),
	   Agruppe AgeType NOT NULL,
       PRIMARY KEY(Bez)
);

CREATE TABLE wirbt (
       Verlagsname VARCHAR(255),
       Kanal VARCHAR(255),
	   Zielgruppe VARCHAR(255),
	   Datum DATE NOT NULL,
       FOREIGN KEY (Verlagsname) REFERENCES Verlag(Name),	   
       FOREIGN KEY (Kanal) REFERENCES Marketingkanal(KName),	   
       FOREIGN KEY (Zielgruppe) REFERENCES Zielgruppe(Bez),	   
	   PRIMARY KEY(Verlagsname, Kanal, Zielgruppe),
	   UNIQUE(Verlagsname, Zielgruppe, Datum)
);


CREATE TABLE nutzt (
	   Zielgruppe VARCHAR(255),
       SocialKanal VARCHAR(255),
       FOREIGN KEY (Zielgruppe) REFERENCES Zielgruppe(Bez),	   
       FOREIGN KEY (SocialKanal) REFERENCES Social(Kanal),	   
	   PRIMARY KEY(Zielgruppe, SocialKanal)
);

CREATE TABLE interessiert (
	   Zielgruppe VARCHAR(255),
       Schriftstueck INTEGER,
       FOREIGN KEY (Zielgruppe) REFERENCES Zielgruppe(Bez),	   
       FOREIGN KEY (Schriftstueck) REFERENCES Schriftstueck(SID),	   
	   PRIMARY KEY(Zielgruppe, Schriftstueck)
);

CREATE TABLE liebt (
	   Zielgruppe VARCHAR(255),
       Autorin INTEGER,
       FOREIGN KEY (Zielgruppe) REFERENCES Zielgruppe(Bez),	   
       FOREIGN KEY (Autorin) REFERENCES Autorin(AID),	   
	   PRIMARY KEY(Zielgruppe, Autorin)
);

CREATE TABLE hasst (
	   Zielgruppe VARCHAR(255),
       Autorin INTEGER,
       FOREIGN KEY (Zielgruppe) REFERENCES Zielgruppe(Bez),	   
       FOREIGN KEY (Autorin) REFERENCES Autorin(AID),	   
	   PRIMARY KEY(Zielgruppe, Autorin)
);

CREATE TABLE aka (
	   alias INTEGER,
       aliasVon INTEGER,
       FOREIGN KEY (alias) REFERENCES Autorin(AID),	   
       FOREIGN KEY (aliasVon) REFERENCES Autorin(AID),	   
	   PRIMARY KEY(alias, aliasVon)
);

CREATE TABLE basiertAuf (
	   alt INTEGER,
       neu INTEGER,
       FOREIGN KEY (alt) REFERENCES Roman(SID),	   
       FOREIGN KEY (neu) REFERENCES Roman(SID),	   
	   PRIMARY KEY(alt, neu)
);