DROP TRIGGER trFixHasWritten ON schrieb;
DROP FUNCTION fFixHasWritten();

DROP TRIGGER trCostsChange ON Marketingkanal;
DROP FUNCTION fCostsChange();

DROP TRIGGER trAuthorAdd ON liebt;
DROP FUNCTION fAuthorAdd();

DROP FUNCTION CreateAuthor(INTEGER, VARCHAR, DATE);

DROP VIEW NovelDistance;
DROP VIEW AllAliases;
DROP VIEW NumberOfLargeBooks;

ALTER TABLE Edition DROP CONSTRAINT fk_Erstauflage;
ALTER TABLE Verlag DROP CONSTRAINT fk_Hauptabteilung;

DROP TABLE basiertAuf;
DROP TABLE aka;
DROP TABLE hasst;
DROP TABLE liebt;
DROP TABLE interessiert;
DROP TABLE nutzt;
DROP TABLE wirbt;
DROP TABLE Zielgruppe;
DROP TABLE Zeitung;
DROP TABLE Social;
DROP TABLE Marketingkanal;
DROP TABLE Abteilung;
DROP TABLE Auflage;
DROP TABLE Sonderedition;
DROP TABLE Edition;
DROP TABLE Verlag;
DROP TABLE schrieb;
DROP TABLE Autorin;
DROP TABLE ueber;
DROP TABLE Roman;
DROP TABLE Lyrik;
DROP TABLE Sachbuch;
Drop TABLE Schriftstueck;

Drop TYPE AgeType;

Drop SEQUENCE seq_author;
Drop SEQUENCE seq_book;