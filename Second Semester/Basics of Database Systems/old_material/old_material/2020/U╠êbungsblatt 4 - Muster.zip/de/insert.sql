BEGIN;

/* Reihenfolge der DELETE Anweisungen ist wichtig */

DELETE FROM basiertAuf;
DELETE FROM aka;
DELETE FROM hasst;
DELETE FROM liebt;
DELETE FROM interessiert;
DELETE FROM nutzt;
DELETE FROM wirbt;
DELETE FROM Zielgruppe;
DELETE FROM Zeitung;
DELETE FROM Social;
DELETE FROM Marketingkanal;
DELETE FROM Abteilung;
DELETE FROM Auflage;
DELETE FROM Sonderedition;
DELETE FROM Edition;
DELETE FROM Verlag;
DELETE FROM schrieb;
DELETE FROM Autorin;
DELETE FROM ueber;
DELETE FROM Roman;
DELETE FROM Lyrik;
DELETE FROM Sachbuch;
DELETE FROM Schriftstueck;

SELECT setval('seq_author', 10000, false);
SELECT setval('seq_book', 1, false);

COMMIT;

INSERT INTO Schriftstueck(Titel, Seiten) VALUES
       ('Harry Potter', 400),
       ('A Series of Unfortunate Events', 300),
       ('The little Prince', 200),
       ('1984', 500),
	   ('S1', 300),
	   ('S2', 200),
       ('S3', 260),	   
       ('S4', 600),
	   ('R1', 1000),
	   ('R2', 1500),
       ('R3', 2000),	   
       ('R4', 1800),
	   ('L1', 20),
	   ('L2', 60),
       ('L3', 76),	   
       ('L4', 39),
	   ('derStandard', 50);

INSERT INTO Sachbuch (SID) VALUES 	
       (4),
	   (5),
       (6),	   
       (7);

INSERT INTO Lyrik (SID) VALUES 	
       (12),
	   (13),
       (14),	   
       (15);
	   
INSERT INTO Roman (SID, Genre) VALUES 	
       (8, 'Adventure'),
	   (9, 'Adventure'),
       (10, 'Adventure'),	   
       (11, 'Romance');

INSERT INTO ueber (Sachbuch, Roman) VALUES
       (4, 8),
	   (4, 10),
       (4, 11),	   
       (5, 11);	   
	   
INSERT INTO Autorin (Name, GebDat) VALUES
       ('A1', '1990-01-01'),
	   ('A2', '1982-02-04'),
       ('A3', '1945-04-20'),	   
       ('A4', '1959-11-29'),	   
       ('A5', '1959-11-29'),	   
       ('A6', '1991-03-10');	   

INSERT INTO schrieb (Autorin, Schriftstueck, StartDatum) VALUES
       (10000, 12, '2015-08-10'),
       (10035, 13, '2007-12-12'),
	   (10007, 2, '1997-07-26'),
	   (10007, 1, '1999-10-16'),
       (10014, 14, '1966-02-12'),	   
       (10014, 15, '1976-12-12'),	   
       (10014, 5, '1964-06-25'),
       (10014, 6, '1950-12-06'),
       (10014, 7, '1951-10-15'),
       (10014, 8, '1966-02-22'),
       (10021, 9, '1968-08-25'), 
       (10021, 10, '1969-01-01'),   
       (10021, 11, '1970-01-06'),   
       (10021, 3, '1975-05-06'),  
       (10028, 4, '1980-03-12'),
	   (10021, 16, '2002-02-02');

BEGIN;

INSERT INTO Verlag (Name, Budget, HauptabteilungStadt, HauptabteilungBereich) VALUES
       ('V1', '2000', 'Wien', 'BB100'),
	   ('V2', '5000', 'London', 'BB113'),
       ('V3', '100000', 'Hamburg', 'BZ222'),	   
       ('V4', '15', 'Wien', 'BB234');

INSERT INTO Abteilung (Verlagsname, Bereich, Stadt) VALUES
       ('V1', 'BB100', 'Wien'),
       ('V2', 'BB113', 'London'),
       ('V3', 'BZ222', 'Hamburg'),
       ('V4', 'BB234', 'Wien');
	   
COMMIT;

BEGIN;

INSERT INTO Edition (Schriftstueck, EDNR, Jahr, Verlagsname, ErstauflageANR) VALUES
       (1, 1, '2010', 'V1', 0),
       (1, 2, '2012', 'V1', 0),
       (1, 3, '2015', 'V1', 0),
	   (1, 4, '2019', 'V4', 0),
       (2, 1, '2018', 'V2', 1),
       (3, 1, '2020', 'V2', 1),
       (4, 0, '2011', 'V2', 1),
	   (4, 1, '2015', 'V3', 2),
	   (5, 1, '2016', 'V3', 1),
       (6, 1, '2018', 'V3', 1),	   
       (7, 0, '2015', 'V3', 1),
	   (8, 1, '2014', 'V4', 1),
	   (9, 1, '2011', 'V4', 1),
       (10, 1, '2009', 'V4', 1),	   
       (11, 1, '2008', 'V4', 1),
	   (12, 1, '2014', 'V4', 1),
	   (13, 1, '2018', 'V4', 0),
       (14, 1, '2022', 'V4', 1),	   
       (15, 1, '2023', 'V4', 1),
	   (16, 0, '2020', 'V4', 0);

INSERT INTO Auflage (Schriftstueck, EDNR, ANR, Druckerei) VALUES
       (1, 1, 0, 'D1'),
       (1, 1, 1, 'D1'),
       (1, 1, 2, 'D1'),
       (1, 2, 0, 'D2'),
       (1, 2, 1, 'D2'),
       (1, 3, 0, 'D3'),
       (1, 3, 1, 'D3'),
       (1, 3, 2, 'D4'),
	   (1, 4, 0, 'D4'),
	   (2, 1, 1, 'D4'),
	   (3, 1, 1, 'D4'),
	   (4, 0, 1, 'D4'),
	   (4, 1, 2, 'D4'),
	   (5, 1, 1, 'D3'),
       (6, 1, 1, 'D3'),	   
       (7, 0, 1, 'D2'),
	   (8, 1, 1, 'D1'),
	   (9, 1, 1, 'D1'),
       (10, 1, 1, 'D1'),	   
       (11, 1, 1, 'D2'),
	   (12, 1, 1, 'D2'),
	   (13, 1, 0, 'D2'),
       (14, 1, 1, 'D1'),	   
       (15, 1, 1, 'D1'),
	   (16, 0, 0, 'D3');


COMMIT;

INSERT INTO Sonderedition (Schriftstueck, EDNR, Anlass) VALUES
       (1, 4, 'Geburtstag des Kindes der Autorin'),
       (3, 1, 'Franzoesischer Feiertag'),
       (4, 1, 'Unabhaengigkeitstag'),
       (15, 1, '30 Jahre des Genres');

INSERT INTO Marketingkanal (KName, Kosten) VALUES
       (4, 100.00),
       (5, 1140.00),
       (6, 1890.00),
       (7, 200000.00),
	   ('Z1', 4098.00),
       ('Z2', 5792.00),
       ('Z3', 19020.00),
       ('Z4', 36000.00);

INSERT INTO Social (Kanal, Platform) VALUES
       (4, 'P1'),
       (5, 'P2'),
       (6, 'P3'),
       (7, 'P4');
	   
INSERT INTO Zeitung (Kanal, Schriftstueck, Auflage) VALUES
       ('Z1', 16, 10),
       ('Z2', 16, 11),
       ('Z3', 16, 10),
       ('Z4', 16, 13);

INSERT INTO Zielgruppe (Bez, Agruppe) VALUES
       ('Kids', 'young'),
       ('Teenagers', 'young'),
       ('Adults', 'middle-aged'),
       ('Retirees', 'old');

INSERT INTO wirbt (Verlagsname, Kanal, Zielgruppe, Datum) VALUES
       ('V1', 4, 'Kids', '2020-10-29'),
       ('V2', 5, 'Teenagers', '2020-11-20'),
       ('V2', 'Z1', 'Adults', '2020-02-07'),
       ('V2', 'Z2', 'Retirees', '2019-05-16'),
       ('V3', 6, 'Teenagers', '2020-08-05'),
       ('V4', 7, 'Kids', '2020-01-14');

INSERT INTO nutzt (Zielgruppe, SocialKanal) VALUES
       ('Kids', 4),
       ('Kids', 5),
       ('Kids', 6),
       ('Teenagers', 5),
       ('Teenagers', 6),
       ('Adults', 7);

INSERT INTO interessiert (Zielgruppe, Schriftstueck) VALUES
       ('Kids', 3),
       ('Kids', 1),
       ('Kids', 2),
       ('Teenagers', 1),
       ('Teenagers', 2),
       ('Adults', 16),
       ('Retirees', 16);	   

INSERT INTO liebt (Zielgruppe, Autorin) VALUES
       ('Kids', 10000),
       ('Kids', 10007),
       ('Kids', 10014),
       ('Teenagers', 10014),
       ('Adults', 10014),
       ('Adults', 10021),
       ('Retirees', 10000);

INSERT INTO hasst (Zielgruppe, Autorin) VALUES
       ('Kids', 10021),
       ('Teenagers', 10000),
       ('Teenagers', 10021),
       ('Adults', 10007),
       ('Retirees', 10007);

INSERT INTO aka (alias, aliasVon) VALUES
       (10021, 10028),
       (10000, 10035),
       (10035, 10007),
       (10007, 10014);
	   
INSERT INTO basiertAuf (alt, neu) VALUES 
	   (8, 9),
	   (9, 10),
	   (10, 8),
	   (10, 11);