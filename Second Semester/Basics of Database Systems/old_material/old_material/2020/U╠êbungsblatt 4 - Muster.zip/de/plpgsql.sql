--- Trigger for 4.a --- Startdatum des Schriftstuecks liegt nicht vor GebDat der Autorin
CREATE OR REPLACE FUNCTION fFixHasWritten() RETURNS TRIGGER AS $$
DECLARE
    GebDat DATE;
BEGIN
      SELECT a.GebDat INTO GebDat FROM Autorin a  WHERE a.AID = NEW.Autorin;
      IF GebDat > New.Startdatum THEN
        RETURN NULL;
	  END IF; 
      RETURN NEW;
END;
$$ LANGUAGE plpgsql;

CREATE TRIGGER trFixHasWritten BEFORE INSERT
    ON schrieb FOR EACH ROW EXECUTE PROCEDURE fFixHasWritten();


--- Trigger for 4.b --- UPDATE Kosten
CREATE OR REPLACE FUNCTION fCostsChange() RETURNS TRIGGER AS $$
BEGIN
    IF NEW.Kosten != OLD.Kosten THEN
       UPDATE Verlag SET Budget = Budget + (New.Kosten - Old.Kosten)
       	      WHERE Name in (SELECT v.Name FROM Verlag v, wirbt w 
							WHERE v.Name = w.Verlagsname AND w.Kanal = Old.KName) AND
					Old.Kname = New.KName;
		    
	RAISE NOTICE 'Kanalkosten um %euro erhoeht', (New.Kosten - Old.Kosten);
    ELSIF NEW.Kosten = OLD.Kosten THEN
        RAISE WARNING 'Kosten blieb gleich!';
    END IF;

    RETURN NEW;
END;
$$ LANGUAGE plpgsql;

CREATE TRIGGER trCostsChange AFTER UPDATE OF Kosten ON Marketingkanal
       FOR EACH ROW EXECUTE PROCEDURE fCostsChange();
	   
	   
--- Trigger for 4.c ---
CREATE OR REPLACE FUNCTION fAuthorAdd() RETURNS TRIGGER AS $$
DECLARE
    rec RECORD;
BEGIN
    FOR rec in (SELECT aliasVon FROM aka WHERE NEW.Autorin = alias) LOOP
	IF NOT EXISTS(SELECT * FROM liebt WHERE
	       	      Autorin = rec.aliasVon AND Zielgruppe = New.Zielgruppe) THEN
	    INSERT INTO liebt VALUES (NEW.Zielgruppe, rec.aliasVon);
        END IF;					    
    END LOOP;

    RETURN NULL;
END;
$$ LANGUAGE plpgsql;

CREATE TRIGGER trAuthorAdd AFTER INSERT ON liebt
       FOR EACH ROW EXECUTE PROCEDURE fAuthorAdd();


--- Prozedure for 4.d ---

CREATE OR REPLACE FUNCTION CreateAuthor(IN numBooks INTEGER, IN authorName VARCHAR, IN gebDat DATE) RETURNS VOID AS
$$
DECLARE
    alias VARCHAR(255);
BEGIN
    IF numBooks < 3 THEN
        RAISE EXCEPTION 'Number of books must at least be 3';
    END IF;

	alias = Left(split_part(authorName, ' ', 1), 1) || '.' 
	|| Left(split_part(authorName, ' ', 2), 1) || '.';

    -- Need to check explicitely that authors of same name or alias not present (name is not a key attribute!)
    IF EXISTS(SELECT * FROM Autorin a WHERE a.name = authorName OR a.name = alias) THEN
        RAISE EXCEPTION 'Author "%" or alias "%" already exists!', authorName, alias;
    END IF;

    -- Using nextval and currval to get right IDs here: 
    INSERT INTO Autorin VALUES (nextval('seq_author'), authorName, gebDat);
    INSERT INTO Autorin VALUES (nextval('seq_author'), alias, gebDat);
    INSERT INTO aka VALUES (currval('seq_author'), currval('seq_author') - 7);
    
    -- Create books
    FOR counter IN 0 .. numBooks - 1
    LOOP
        CASE counter % 3 
	    WHEN 0 THEN
				INSERT INTO Schriftstueck VALUES 
				(nextval('seq_book'), concat('Novel of ', alias), 100);
				INSERT INTO Roman VALUES 
				(currval('seq_book'), 'Adventure');
            WHEN 1 THEN
				INSERT INTO Schriftstueck VALUES 
				(nextval('seq_book'), concat('Poetry of ', alias), 100);
				INSERT INTO Lyrik VALUES 
				(currval('seq_book'));
            WHEN 2 THEN
				INSERT INTO Schriftstueck VALUES 
				(nextval('seq_book'), concat('Non-fiction of ', alias), 100);
				INSERT INTO Sachbuch VALUES 
				(currval('seq_book'));
        END CASE;
   END LOOP;
   
    FOR counter IN 0 .. numBooks - 1
    LOOP
        INSERT INTO schrieb (autorin, schriftstueck, startdatum) VALUES (currval('seq_author'), currval('seq_book') - counter, CURRENT_DATE);
   END LOOP;
END;
$$ LANGUAGE plpgsql;