--- Query 1 -- Anzahl der Buecher pro Autor mit mehr als 200 Seiten
CREATE OR REPLACE VIEW NumberOfLargeBooks AS
       SELECT   a.AID, COUNT(s.SID)
       FROM     Autorin a , schrieb, Schriftstueck s
       WHERE    a.AID = schrieb.Autorin AND schrieb.Schriftstueck = s.SID
                AND s.Seiten > 200
       GROUP BY a.AID;
   
SELECT * FROM NumberOfLargeBooks;

--- Query 2 -- Transitiver Abschluss von Alias
CREATE OR REPLACE VIEW AllAliases AS
WITH RECURSIVE tmp(alias, aliasVon) as ( 
       SELECT * FROM aka
       UNION
       SELECT a.alias, tmp.aliasVon FROM aka a, tmp WHERE tmp.alias = a.aliasVon
       ) select * from tmp;
SELECT * FROM AllAliases;

--- Query 3 -- Distanz Metrik für aufeinanderbasierender Romane des gleichen Genres
CREATE OR REPLACE VIEW NovelDistance AS
WITH RECURSIVE tmp(alt, neu, Genre, distanz) AS ( 
        SELECT b.alt, b.neu, r2.Genre, 1 
        FROM basiertAuf b, Roman r1, Roman r2 
        WHERE b.alt = r1.SID AND b.neu = r2.SID AND r1.Genre = r2.Genre
       UNION 
        SELECT t.alt, b.neu, r.Genre, distanz + 1
        FROM basiertAuf b, Roman r, tmp t
	WHERE b.alt = t.neu AND b.neu = r.SID AND t.Genre = r.Genre AND 
	distanz < (SELECT count(*) FROM basiertAuf) 
	--- ''Distance < Cardianlitaet(basiertAuf)'' um Kreise in der DB (ungezuegelte Rekursion) abzufangen! 
       ) select alt, neu, Genre, MIN(distanz) from tmp GROUP BY alt, neu, Genre;
SELECT * FROM NovelDistance;
