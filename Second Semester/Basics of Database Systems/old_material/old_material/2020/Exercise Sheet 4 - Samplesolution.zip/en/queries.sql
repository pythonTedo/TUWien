--- Query 1 -- Number of books per author with more than 200 pages
CREATE OR REPLACE VIEW NumberOfLargeBooks AS
       SELECT   a.AID, COUNT(s.BID)
       FROM     author a , hasWritten, book s
       WHERE    a.AID = hasWritten.author AND hasWritten.book = s.BID
                AND s.pages > 200
       GROUP BY a.AID;
   
SELECT * FROM NumberOfLargeBooks;

--- Query 2 -- Transitive closure of alias
CREATE OR REPLACE VIEW AllAliases AS
WITH RECURSIVE tmp(alias, aliasOf) as ( 
       SELECT * FROM aka
       UNION
       SELECT a.alias, tmp.aliasOf FROM aka a, tmp WHERE tmp.alias = a.aliasOf
       ) select * from tmp;
SELECT * FROM AllAliases;

--- Query 3 -- Distance metric for novels that are based on novels of the same genre recursively
CREATE OR REPLACE VIEW NovelDistance AS
WITH RECURSIVE tmp(old, new, genre, distance) AS ( 
        SELECT b.old, b.new, n2.genre, 1 
        FROM basedOn b, novel n1, novel n2 
        WHERE b.old = n1.BID AND b.new = n2.BID AND n1.genre = n2.genre
       UNION 
        SELECT t.old, b.new, r.genre, distance + 1
        FROM basedOn b, novel r, tmp t
	WHERE b.old = t.new AND b.new = r.BID AND t.genre = r.genre AND 
	distance < (SELECT count(*) FROM basedOn) 
	--- ''Distance < cardianlity(basedOn)'' to mitigate cycles in the DB (uncontrolled rekursion)! 
       ) select old, new, genre, MIN(distance) from tmp GROUP BY old, new, genre;
SELECT * FROM NovelDistance;
