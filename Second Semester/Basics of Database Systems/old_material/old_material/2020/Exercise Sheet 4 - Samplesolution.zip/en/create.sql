CREATE SEQUENCE seq_book;
CREATE SEQUENCE seq_author INCREMENT BY 7 MINVALUE 10000 NO CYCLE;
CREATE TYPE AgeType AS ENUM ('young', 'middle-aged', 'old');

CREATE TABLE book (
	   BID INTEGER DEFAULT nextval('seq_book'), 
       titel VARCHAR(255),
	   pages INTEGER NOT NULL,
       PRIMARY KEY(BID)
);

CREATE TABLE nonFiction (
	   BID INTEGER,
       FOREIGN KEY (BID) REFERENCES book(BID),
	   PRIMARY KEY(BID)
);

CREATE TABLE poetry (
	   BID INTEGER,
       FOREIGN KEY (BID) REFERENCES book(BID),
	   PRIMARY KEY(BID)
);

CREATE TABLE novel (
	   BID INTEGER,
	   genre VARCHAR(255) NOT NULL,
       FOREIGN KEY (BID) REFERENCES book(BID),
	   PRIMARY KEY(BID)
);

CREATE TABLE about (
       nonFiction INTEGER,
       novel INTEGER,
       FOREIGN KEY (nonFiction) REFERENCES nonFiction(BID),
       FOREIGN KEY (novel) REFERENCES novel(BID),
	   PRIMARY KEY(nonFiction, novel)
);

CREATE TABLE author (
	   AID INTEGER DEFAULT nextval('seq_author'),
       name VARCHAR(255),
       DOB DATE,
	   PRIMARY KEY(AID)
);

CREATE TABLE hasWritten (
       author INTEGER,
       book INTEGER,
	   startDate DATE NOT NULL,
       FOREIGN KEY (author) REFERENCES author(AID),
       FOREIGN KEY (book) REFERENCES book(BID),
	   PRIMARY KEY(author, book)
);

CREATE TABLE publisher (
       name VARCHAR(255),
	   budget NUMERIC(10,2) NOT NULL CHECK(budget >= 10 AND budget <= 1000000),
	   mainCity VARCHAR(255), 
	   mainArea VARCHAR(255),
	   PRIMARY KEY(name)
);

CREATE TABLE edition (
       book INTEGER,
	   EDNR INTEGER, 
	   year INTEGER NOT NULL CHECK(year >= 1400),
	   publisher VARCHAR(255) NOT NULL,
	   FirstPrintingPNR INTEGER,
       FOREIGN KEY (book) REFERENCES book(BID),
       FOREIGN KEY (publisher) REFERENCES publisher(name),
	   PRIMARY KEY(book, EDNR)
);

CREATE TABLE specialEdition (
       book INTEGER,
	   EDNR INTEGER, 
	   reason VARCHAR(255) NOT NULL,
       FOREIGN KEY (book, EDNR) REFERENCES edition(book, EDNR),
	   PRIMARY KEY(book, EDNR)
);

CREATE TABLE printing (
       book INTEGER,
	   EDNR INTEGER, 
	   PNR INTEGER,
	   printer VARCHAR(255) NOT NULL,
       FOREIGN KEY (book, EDNR) REFERENCES edition(book, EDNR),
	   PRIMARY KEY(book, EDNR, PNR)
);

CREATE TABLE department (
       publisher VARCHAR(255),
	   area VARCHAR(255) CHECK(area ~ $$^\w{2}\d{3}$$),
	   city VARCHAR(255),
       FOREIGN KEY (publisher) REFERENCES publisher(name),	   
	   PRIMARY KEY(publisher, area, city)
);

ALTER TABLE publisher ADD CONSTRAINT fk_MainDepartment
      FOREIGN KEY (name, mainCity, mainArea) REFERENCES department(publisher, city, area)
      DEFERRABLE INITIALLY DEFERRED;

ALTER TABLE edition ADD CONSTRAINT fk_FirstPrinting
      FOREIGN KEY (book, EDNR, FirstPrintingPNR) REFERENCES printing(book, EDNR, PNR)
      DEFERRABLE INITIALLY DEFERRED;

CREATE TABLE marketingChannel (
       chName VARCHAR(255),
	   costs NUMERIC(10,2) NOT NULL,
	   PRIMARY KEY(chName)
);

CREATE TABLE social (
       channel VARCHAR(255),
	   platform VARCHAR(255) NOT NULL,
       FOREIGN KEY (channel) REFERENCES marketingChannel(chName),	   
	   PRIMARY KEY(channel)
);

CREATE TABLE newspaper (
       channel VARCHAR(255),
	   book INTEGER,
	   printing INTEGER NOT NULL,
       FOREIGN KEY (channel) REFERENCES marketingChannel(chName),	   
       FOREIGN KEY (book) REFERENCES book(BID),	   
	   PRIMARY KEY(channel, book)
);

CREATE TABLE targetGroup (
       description VARCHAR(255),
	   age AgeType NOT NULL,
       PRIMARY KEY(description)
);

CREATE TABLE advertises (
       publisher VARCHAR(255),
       channel VARCHAR(255),
	   targetGroup VARCHAR(255),
	   date DATE NOT NULL,
       FOREIGN KEY (publisher) REFERENCES publisher(name),	   
       FOREIGN KEY (channel) REFERENCES marketingChannel(chName),	   
       FOREIGN KEY (targetGroup) REFERENCES targetGroup(description),	   
	   PRIMARY KEY(publisher, channel, targetGroup),
	   UNIQUE(publisher, targetGroup, date)
);


CREATE TABLE uses (
	   targetGroup VARCHAR(255),
       social VARCHAR(255),
       FOREIGN KEY (targetGroup) REFERENCES targetGroup(description),	   
       FOREIGN KEY (social) REFERENCES social(channel),	   
	   PRIMARY KEY(targetGroup, social)
);

CREATE TABLE interestedIn (
	   targetGroup VARCHAR(255),
       book INTEGER,
       FOREIGN KEY (targetGroup) REFERENCES targetGroup(description),	   
       FOREIGN KEY (book) REFERENCES book(BID),	   
	   PRIMARY KEY(targetGroup, book)
);

CREATE TABLE loves (
	   targetGroup VARCHAR(255),
       author INTEGER,
       FOREIGN KEY (targetGroup) REFERENCES targetGroup(description),	   
       FOREIGN KEY (author) REFERENCES author(AID),	   
	   PRIMARY KEY(targetGroup, author)
);

CREATE TABLE hates (
	   targetGroup VARCHAR(255),
       author INTEGER,
       FOREIGN KEY (targetGroup) REFERENCES targetGroup(description),	   
       FOREIGN KEY (author) REFERENCES author(AID),	   
	   PRIMARY KEY(targetGroup, author)
);

CREATE TABLE aka (
	   alias INTEGER,
       aliasOf INTEGER,
       FOREIGN KEY (alias) REFERENCES author(AID),	   
       FOREIGN KEY (aliasOf) REFERENCES author(AID),	   
	   PRIMARY KEY(alias, aliasOf)
);

CREATE TABLE basedOn (
	   old INTEGER,
       new INTEGER,
       FOREIGN KEY (old) REFERENCES novel(BID),	   
       FOREIGN KEY (new) REFERENCES novel(BID),	   
	   PRIMARY KEY(old, new)
);