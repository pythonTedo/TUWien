DROP TRIGGER trFixHasWritten ON hasWritten;
DROP FUNCTION fFixHasWritten();

DROP TRIGGER trCostsChange ON marketingChannel;
DROP FUNCTION fCostsChange();

DROP TRIGGER trAuthorAdd ON loves;
DROP FUNCTION fAuthorAdd();

DROP FUNCTION CreateAuthor(INTEGER, VARCHAR, DATE);

DROP VIEW NovelDistance;
DROP VIEW AllAliases;
DROP VIEW NumberOfLargeBooks;

ALTER TABLE edition DROP CONSTRAINT fk_FirstPrinting;
ALTER TABLE publisher DROP CONSTRAINT fk_MainDepartment;

DROP TABLE basedOn;
DROP TABLE aka;
DROP TABLE hates;
DROP TABLE loves;
DROP TABLE interestedIn;
DROP TABLE uses;
DROP TABLE advertises;
DROP TABLE targetGroup;
DROP TABLE newsPaper;
DROP TABLE social;
DROP TABLE marketingChannel;
DROP TABLE department;
DROP TABLE printing;
DROP TABLE specialEdition;
DROP TABLE edition;
DROP TABLE publisher;
DROP TABLE hasWritten;
DROP TABLE author;
DROP TABLE about;
DROP TABLE novel;
DROP TABLE poetry;
DROP TABLE nonFiction;
Drop TABLE book;

Drop TYPE AgeType;

Drop SEQUENCE seq_author;
Drop SEQUENCE seq_book;