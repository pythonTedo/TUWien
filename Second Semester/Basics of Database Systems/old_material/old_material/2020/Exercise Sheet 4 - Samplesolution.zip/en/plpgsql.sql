--- Trigger for 4.a --- startdate of the book is not allowed to be before the birthday of the author
CREATE OR REPLACE FUNCTION fFixHasWritten() RETURNS TRIGGER AS $$
DECLARE
    DOB DATE;
BEGIN
      SELECT a.DOB INTO DOB FROM author a WHERE a.AID = NEW.author;
      IF DOB > New.startdate THEN
        RETURN NULL;
	  END IF; 
      RETURN NEW;
END;
$$ LANGUAGE plpgsql;

CREATE TRIGGER trFixHasWritten BEFORE INSERT
    ON hasWritten FOR EACH ROW EXECUTE PROCEDURE fFixHasWritten();


--- Trigger for 4.b --- UPDATE costs
CREATE OR REPLACE FUNCTION fCostsChange() RETURNS TRIGGER AS $$
BEGIN
    IF NEW.costs != OLD.costs THEN
       UPDATE publisher SET budget = budget + (New.costs - Old.costs)
       	      WHERE name in (SELECT p.name FROM publisher p, advertises a 
							WHERE p.name = a.publisher AND a.channel = Old.chName) AND
					Old.chName = New.chName;
		    
	RAISE NOTICE 'Costs of the channel were increased by %euros', (New.costs - Old.costs);
    ELSIF NEW.costs = OLD.costs THEN
        RAISE WARNING 'Costs did not change!';
    END IF;

    RETURN NEW;
END;
$$ LANGUAGE plpgsql;

CREATE TRIGGER trCostsChange AFTER UPDATE OF costs ON Marketingchannel
       FOR EACH ROW EXECUTE PROCEDURE fCostsChange();
	   
	   
--- Trigger for 4.c ---
CREATE OR REPLACE FUNCTION fAuthorAdd() RETURNS TRIGGER AS $$
DECLARE
    rec RECORD;
BEGIN
    FOR rec in (SELECT aliasOf FROM aka WHERE NEW.author = alias) LOOP
	IF NOT EXISTS(SELECT * FROM loves WHERE
	       	      author = rec.aliasOf AND targetGroup = New.targetGroup) THEN
	    INSERT INTO loves VALUES (NEW.targetGroup, rec.aliasOf);
        END IF;					    
    END LOOP;

    RETURN NULL;
END;
$$ LANGUAGE plpgsql;

CREATE TRIGGER trAuthorAdd AFTER INSERT ON loves
       FOR EACH ROW EXECUTE PROCEDURE fAuthorAdd();


--- Prozedure for 4.d ---

CREATE OR REPLACE FUNCTION CreateAuthor(IN numBooks INTEGER, IN authorName VARCHAR, IN DOB DATE) RETURNS VOID AS
$$
DECLARE
    alias VARCHAR(255);
BEGIN
    IF numBooks < 3 THEN
        RAISE EXCEPTION 'Number of books must at least be 3';
    END IF;

	alias = Left(split_part(authorName, ' ', 1), 1) || '.' 
	|| Left(split_part(authorName, ' ', 2), 1) || '.';

    -- Need to check explicitely that authors of same name or alias not present (name is not a key attribute!)
    IF EXISTS(SELECT * FROM author a WHERE a.name = authorName OR a.name = alias) THEN
        RAISE EXCEPTION 'Author "%" or alias "%" already exists!', authorName, alias;
    END IF;

    -- Using nextval and currval to get right IDs here: 
    INSERT INTO author VALUES (nextval('seq_author'), authorName, DOB);
    INSERT INTO author VALUES (nextval('seq_author'), alias, DOB);
    INSERT INTO aka VALUES (currval('seq_author'), currval('seq_author') - 7);
    
    -- Create books
    FOR counter IN 0 .. numBooks - 1
    LOOP
        CASE counter % 3 
	    WHEN 0 THEN
				INSERT INTO book VALUES 
				(nextval('seq_book'), concat('Novel of ', alias), 100);
				INSERT INTO novel VALUES 
				(currval('seq_book'), 'Adventure');
            WHEN 1 THEN
				INSERT INTO book VALUES 
				(nextval('seq_book'), concat('Poetry of ', alias), 100);
				INSERT INTO poetry VALUES 
				(currval('seq_book'));
            WHEN 2 THEN
				INSERT INTO book VALUES 
				(nextval('seq_book'), concat('Non-fiction of ', alias), 100);
				INSERT INTO nonFiction VALUES 
				(currval('seq_book'));
        END CASE;
   END LOOP;
   
    FOR counter IN 0 .. numBooks - 1
    LOOP
        INSERT INTO hasWritten (author, book, startdate) VALUES (currval('seq_author'), currval('seq_book') - counter, CURRENT_DATE);
   END LOOP;
END;
$$ LANGUAGE plpgsql;